<template src="./product.component.html"></template>
<script src="./product.component.js"></script>
<style src="./product.component.scss" scoped lang="scss"></style>

