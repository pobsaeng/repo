<template src="./profile.component.html"></template>
<script src="./profile.component.js"></script>
<style src="./profile.component.scss" scoped lang="scss"></style>

