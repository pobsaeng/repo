import { EventBus } from '@/trigger-global/trigger-event-component.js';

export default {
  name: 'profile',
  components: {}, 
  props: [],
  data () {
    return {

    }
  },
  computed: {

  },
  mounted () {

  },
  methods: {

  }
}
