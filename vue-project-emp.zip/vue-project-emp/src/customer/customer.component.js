import { EventBus } from '@/misc/event-bus.js';

import modal from '@/modal/index'
export default {
  name: 'customer',
  components: { modal },
  props: [],
  data() {
    return {
      showModal: false,
      items: [],
      originalItems: [],
      itemSearch: '',
      actionStatus: true
    }
  },
  created() {
    EventBus.$on("modal-values", (values) => {
      //add
      if (this.actionStatus) {
        this.items.push(values);
        this.originalItems = this.items.slice();
      }
      //edit
      else {
        console.log(values);
        var state = this.items;
        for (var i = 0; i < state.length; ++i) {
          if (state[i].title == values.title) {
            state[i].title = values.title;
            state[i].body = values.body;
          }
        }
      }
    });
  },
  computed: {

  },
  mounted() {

  },
  methods: {
    showDialog() {
      this.showModal = true;
      this.actionStatus = true
    },
    rowEdit(item) {
      this.showModal = true;
      EventBus.$emit('modal-data-bind', item);
      this.actionStatus = false;

      console.log(item);
    },
    rowRemove(item) {
      var message = "Remove this record?";
      var options = {
        html: false, // set to true if your message contains HTML tags. eg: "Delete <b>Foo</b> ?"
        loader: false, // set to true if you want the dailog to show a loader after click on "proceed"
        reverse: false, // switch the button positions (left to right, and vise versa)
        okText: 'Continue',
        cancelText: 'Close',
        animation: 'zoom', // Available: "zoom", "bounce", "fade"
        type: 'basic', // coming soon: 'soft', 'hard'
        verification: 'continue', // for hard confirm, user will be prompted to type this to enable the proceed button
        verificationHelp: 'Type "[+:verification]" below to confirm', // Verification help text. [+:verification] will be matched with 'options.verification' (i.e 'Type "continue" below to confirm')
        clicksCount: 3, // for soft confirm, user will be asked to click on "proceed" btn 3 times before actually proceeding
        backdropClose: false // set to true to close the dialog when clicking outside of the dialog window, i.e. click landing on the mask 
      };
      var me = this;

      this.$dialog.confirm(message, options)
        .then(function () {
          var jsonArray = me.items;
          for (var i = 0; i < jsonArray.length; i++) {
            if (jsonArray[i].title == item.title) {
              jsonArray.splice(i, 1);
            }
          }

          me.originalItems = jsonArray.slice();

        }).catch(function () { });
    },
    rowDetail(item) {
      this.$toast.success({
        title: 'Message',
        message: 'Comming soon!'
      })
    },
    searchProducts: function () {
      var searchedList = [];
      for (var i = 0; i < this.originalItems.length; i++) {
        var title = this.originalItems[i]['title'].toLowerCase();
        if (title.indexOf(this.itemSearch.toLowerCase()) >= 0) {
          searchedList.push(this.originalItems[i]);
        }
      }

      this.items = searchedList;
    }
  }
}
