<template src="./productbox.component.html"></template>
<script src="./productbox.component.js"></script>
<style src="./productbox.component.scss" scoped lang="scss"></style>

