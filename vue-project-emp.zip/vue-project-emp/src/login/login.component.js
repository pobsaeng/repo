import navbar from '@/components/navbar/index'
import { EventBus } from '@/misc/event-bus.js';

export default {
  name: 'login',
  components: {},
  props: [],
  data() {
    return {
    }
  },
  computed: {

  },
  mounted() {

  },
  created() {
  },
  methods: {
    login() {
      let email = this.$refs.email.value;
      let password = this.$refs.password.value;

      localStorage.jwtToken = email + password; //This save to local storage
      EventBus.$emit('loggedIn-checked', true);

      this.$router.push('/pos');
    }
  }
}
