import Vue from 'vue'
import $ from 'jquery' 

export default {
  name: 'sidebar',
  components: {}, 
  props: [],
  data () {
    return {

    }
  },
  computed: {

  },
  mounted () {

  },
  methods: {

  }
}
